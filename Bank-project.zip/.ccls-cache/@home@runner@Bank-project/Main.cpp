// Junaid Ahmed

#include <iostream>
#include "BankDetails.hpp"
#include "AccountDetails.hpp"

void delete_acct(BankDetails& bank) {
    int index;
    int input1;

    std::cout << std::endl << "Enter the account number: ";
    std::cin >> input1;

    if (input1 != 0) {
        index = bank.findAccountByNum(input1);
        if (index >= 0) {
            if (bank.deleteBankAccount(index))
                std::cout << "Account is closed." << std::endl;
            else
                std::cout << "Error. Cannot close account." << std::endl;
        } else {
            std::cout << "Error. Account number \"" << input1 << "\" is not found." << std::endl;
        }
    } else {
        std::cout << "Error. Invalid account number." << std::endl;
    }
}

int main() {
    BankDetails bank;

    bank.initializeBank();

    bank.loop();

    return 0;
}
