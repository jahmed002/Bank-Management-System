// Junaid Ahmed

#include "BaseAccount.hpp"
#include <iomanip>

BaseAccount::BaseAccount() {
}

BaseAccount::BaseAccount(int a_num, double balance) {
    AccountNumber = a_num;
    Balance = balance;
}

BaseAccount::BaseAccount(int a_num) {
    AccountNumber = a_num;
    Balance = 0;
}

BaseAccount::~BaseAccount(void) {
}

int BaseAccount::getAccountNumber() {
    return AccountNumber;
}

double BaseAccount::getBalance() {
    return Balance;
}

double BaseAccount::getAmount() {
    double amount1;
    string input;

    do {
        cout << "    Enter amount to deposit:";
        cin >> input;

        char* end = nullptr;
        amount1 = strtod(input.c_str(), &end);

        if (amount1 > 0) {
            break;
        }

        cout << "    | Error. Invalid amount, needed to enter a positive number." << endl;
        cout << endl << endl;
    } while (true);

    return amount1;
}

void BaseAccount::deposit() {
    double amount = getAmount();

    ToDeposit(amount);
    cout << "    | Deposit was successful." << endl;
    cout << "    | The current balance is " << Balance << endl;
    cout << endl;
    cout << endl;
}

void BaseAccount::withdraw() {
    double amount = getAmount();
    if (ToWithdraw(amount)) {
        cout << "    | Withdraw was successful." << endl;
        cout << "    | The current balance is " << Balance << endl;
    } else {
        cout << "    | Error. Insufficient funds." << endl;
    }
}

void BaseAccount::ToDeposit(double amount) {
    Balance += amount;
}

bool BaseAccount::ToWithdraw(double amount1) {
    if (amount1 > Balance) {
        return false;
    } else {
        Balance -= amount1;
        return true;
    }
}

void BaseAccount::printAccountInfo() {
    if (Type == 2) {
        cout << endl;
        cout << "    | Sub-account number: CHK" << getAccountNumber() << endl;
        cout << "    | Balance: " << fixed << setprecision(0) << getBalance() << endl;
        cout << endl;
        cout << "    | The maximum capacity is: " << Capacity << endl;
        cout << "    | The sub-account is " << (Locked == 0 ? "locked" : "not locked") << endl;
        cout << endl;
    } else {
        cout << endl;
        cout << "    | Sub-account number: SAV" << getAccountNumber() << endl;
        cout << "    | Balance: " << fixed << setprecision(0) << getBalance() << endl;
        cout << endl;
    }
}

void BaseAccount::closed() {
    Closed = true;
}

bool BaseAccount::isClosed() {
    return Closed;
}

bool BaseAccount::loop() {
    return false;
}
