// Junaid Ahmed

#include "UserDeposit.hpp"

UserDeposit::UserDeposit(void) {
}

UserDeposit::~UserDeposit(void) {
}

UserDeposit::UserDeposit(const UserDeposit& u_deposit) {
    SSN = u_deposit.SSN;
    Name = u_deposit.Name;
}

UserDeposit::UserDeposit(Username& name, string ssn) {
    SSN = ssn;
    Name = name;
}

Username& UserDeposit::getName() {
    return Name;
}

string UserDeposit::getSSN() {
    return SSN;
}
