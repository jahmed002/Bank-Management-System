// Junaid Ahmed

#pragma once
#include <stdio.h>
#include <string>
#include "BaseAccount.hpp"

using namespace std;

class ChkAccount : public BaseAccount {
private:
public:
    ChkAccount();
    ChkAccount(int savUnique, double balance, double capacity, bool locked);
    ~ChkAccount(void);

    bool loop();

    void deposit();
    void withdraw();
    void CheckCapacity();

    void SetCapacity(double amount);

    void ToUnlock();
    void ToLock();
};
