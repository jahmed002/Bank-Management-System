// Junaid Ahmed

#include "ChkAccount.hpp"

ChkAccount::ChkAccount() {
}

ChkAccount::ChkAccount(int savUnique, double balance, double capacity, bool locked) : BaseAccount(savUnique, balance) {
    Capacity = capacity;
    Locked = locked;
    Type = 2;
}

ChkAccount::~ChkAccount(void) {
}

bool ChkAccount::loop() {
    string UserInput;
    bool exit = false;

    cout << "Eligible services for sub-account CHK" << AccountNumber << endl;
    cout << "        D -- Deposit" << endl;
    cout << "        W -- Withdraw" << endl;
    cout << "        C -- Max Capacity" << endl;
    cout << "        L -- Lock Sub-Account" << endl;
    cout << "        U -- Unlock Sub-Account" << endl;
    cout << "        X -- Exit" << endl;

    cout << "Please enter your selection:";
    cin >> UserInput;

    if (UserInput == "X" || UserInput == "x") {
        cout << "    | End of service for sub-account CHK" << AccountNumber << endl;
        cout << endl;
        cout << endl;

        exit = true;
    } else if (UserInput == "D" || UserInput == "d") {
        deposit();
    } else if (UserInput == "W" || UserInput == "w") {
        withdraw();
    } else if (UserInput == "L" || UserInput == "l") {
        ToLock();
    } else if (UserInput == "U" || UserInput == "u") {
        ToUnlock();
    } else if (UserInput == "C" || UserInput == "c") {
        CheckCapacity();
    }

    return exit;
}

void ChkAccount::deposit() {
    double a1 = getAmount();

    if (Locked == true) {
        cout << "    | The account is currently locked!" << endl;
        cout << "    | The deposit was unsuccessful." << endl;
        cout << endl;
        cout << endl;
        return;
    }
    ToDeposit(a1);
    cout << "    | Deposit was successful." << endl;
    cout << "    | The current balance is " << Balance << endl;
    cout << endl;
    cout << endl;
}

void ChkAccount::withdraw() {
    double a1 = getAmount();

    if (Locked == true) {
        cout << "    | The account is currently locked!" << endl;
        cout << "    | The withdraw was unsuccessful." << endl;
        cout << endl;
        cout << endl;
        return;
    }

    if (ToWithdraw(a1)) {
        cout << "    | Withdraw was successful." << endl;
        cout << "    | The current balance is " << Balance << endl;
        cout << endl;
        cout << endl;
    } else {
        cout << "    | Error. Insufficient funds." << endl;
    }
}

void ChkAccount::CheckCapacity() {
    double amount = getAmount();

    if (Locked == true) {
        cout << "    | The account is currently locked!" << endl;
        cout << "    | The withdraw was unsuccessful." << endl;
        cout << endl;
        cout << endl;
        return;
    }
    SetCapacity(amount);
}

void ChkAccount::SetCapacity(double amount) {
    Capacity = amount;
    cout << "    | Set capacity was successful." << endl;
    cout << "    | The current capacity is " << Capacity << endl;
    cout << endl;
    cout << endl;
}

void ChkAccount::ToUnlock() {
    if (Locked == true) {
        Locked = false;
        cout << "    | The sub-account CHK" << AccountNumber << " is unlocked now!" << endl;
    } else {
        cout << "    | The sub-account CHK" << AccountNumber << " was already unlocked!" << endl;
    }
    cout << endl;
    cout << endl;
}

void ChkAccount::ToLock() {
    if (Locked == false) {
        Locked = true;
        cout << "    | The sub-account CHK" << AccountNumber << " is locked now!" << endl;
    } else {
        cout << "    | The sub-account CHK" << AccountNumber << " was already locked!" << endl;
    }
}
