//Junaid Ahmed
#pragma once

#include <stdio.h>
#include <string>
using namespace std;

#define MAX 1000										
#define BANK_ACCOUNT_START 10000						
#define SAV_ACCOUNT_START 1000							
#define CHK_ACCOUNT_START 6000							
#define SSN_LENGTH 11



class AccountDetails;
class BankDetails{
private:
	string BankName;											//Name of the bank
	string BankAddress;											//Address of the bank
	string BankWorkingHours;									//Working Hours of the bank

	int AccNumber = 0;											
	int BankAcc = BANK_ACCOUNT_START;							
	int SavingAcc = SAV_ACCOUNT_START;							
	int CheckingAcc = CHK_ACCOUNT_START;						
public:
	AccountDetails* ACCOUNTS[MAX];								

	BankDetails(void);
	~BankDetails(void);

	void initializeBank();										//Initialize Bank Details

	void setBankName(string bankName);							//Set Bank Name
	string getBankName();										//Returns Bank Name
	void setBankAddress(string bankAddress);					//Set Bank Address
	string getBankAddress();									//Returns Bank Address
	void setBankWorkingHours(string bankWorkingHours);			//Set Bank Working Hours
	string getBankWorkingHours();								//Returns Bank Working Hours

	void loop();
	void showMenu();											//Shows Bank Menu

	bool validateSSN(string ssn);								//Validate User's Social Security Number

	int open_Account();														//Enter the details to open an account
	int create_Account(string firstName, string lastName, string ssn);		//Create an account

	void close_Account();													//Close an account									

	AccountDetails* mod_Account();											//Modify an account

	void getNumBankAccount();												//Returns the number of a bank account						
	void getNumSavAccount();												//Returns the number of a saving account
	void getNumChkAccount();												//Returns the number of a checking account

	void showDetailedAccount();												//Shows account details
	void showBriefAccountInfo();											//Shows brief account details

	int getSavAccountNum();													//Returns the number of saving accounts
	int getChkAccountNum();													//Returns the number of checking accounts

	int findAccountByNum(int accountNumber);								//Find an account using their number
	int findAccountBySocial(string ssn);									//Find an account using their social security number
	AccountDetails* getAccount(int index);
	bool deleteBankAccount(int index);										//Delete a bank account

	int getAccountsNumber();
};