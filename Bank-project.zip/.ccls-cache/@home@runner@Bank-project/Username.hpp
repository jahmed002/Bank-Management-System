// Junaid Ahmed

#pragma once

#include <stdio.h>
#include <string>

using namespace std;

class Username {
    string FirstName;
    string LastName;

public:
    Username(void);
    Username(const Username& name);
    Username(string fName, string lName);
    ~Username(void);

    string getFirstname();
    string getLastname();
};
