//Junaid Ahmed
#include <vector>
#include <iomanip>
#include "AccountDetails.hpp"
#include "BankDetails.hpp"
#include <iostream>

using namespace std;

BankDetails::BankDetails(void){
	AccNumber = 0;
}

BankDetails::~BankDetails(void){
}

void BankDetails::initializeBank(){
	string bankName;
	string bankAddress;
	string workingHours;

	cout << "Enter the name of the bank: ";
	getline(cin, bankName);
	cout << "Enter the address of the bank: ";
	getline(cin, bankAddress);
	cout << "Enter the working hours: ";
	getline(cin, workingHours);

	setBankName(bankName);
	setBankAddress(bankAddress);
	setBankWorkingHours(workingHours);

	cout << endl << endl;
}

void BankDetails::setBankName(string bankName){
	BankName = bankName;
}

string  BankDetails::getBankName(){
	return BankName;
}

void BankDetails::setBankAddress(string bankAddress){
	BankAddress = bankAddress;
}

string BankDetails::getBankAddress(){
	return BankAddress;
}

void BankDetails::setBankWorkingHours(string bankWorkingHours){
	BankWorkingHours = bankWorkingHours;
}

string BankDetails::getBankWorkingHours(){
	return BankWorkingHours;
}

void BankDetails::loop(){
	bool exit = false;
	string userInput;

	int curAccountNumber = -1;
	AccountDetails* account = NULL;

	do{if (curAccountNumber != -1 &&	account == NULL){
			account = ACCOUNTS[findAccountByNum(curAccountNumber)];
		}

		if (account != NULL){
			if (account->loop()){
				account = NULL;
				curAccountNumber = -1;
			}
		}
		else{
			showMenu();

			cin >> userInput;

			if (userInput == "x" || userInput == "X"){
				cout << endl;
				cout << "    | End of service for bank " << BankName << endl;

				exit = true;
			}
			else if (userInput == "o" || userInput == "O"){
				curAccountNumber = open_Account();
			}
			else if (userInput == "a" || userInput == "A"){
				getNumBankAccount();
			}
			else if (userInput == "s" || userInput == "S"){
				getNumSavAccount();
			}
			else if (userInput == "h" || userInput == "H"){
				getNumChkAccount();
			}
			else if (userInput == "c" || userInput == "C"){
				close_Account();
			}
			else if (userInput == "m" || userInput == "M"){
				account = mod_Account();
			}
			else if (userInput == "d" || userInput == "D"){
				showDetailedAccount();
			}
			else if (userInput == "b" || userInput == "B"){
				showBriefAccountInfo();
			}
			else{
				cout << "    | Invalid enter, please try again." << endl;
				cout << endl;
				cout << endl;
			}
		}
	} while (!exit);
}

void BankDetails::showMenu(){
	cout << "Eligible services for " + getBankName() << endl;
	cout << "       A -- Number of Bank-Accounts" << endl;
	cout << "       S -- Number of Saving-Accounts" << endl;
	cout << "       H -- Number of Checking-Accounts" << endl;
	cout << "       O -- Open Bank-Account" << endl;
	cout << "       C -- Close Bank-Account" << endl;
	cout << "       M -- Modify Bank-Account" << endl;
	cout << "       D -- Detailed Bank-Accounts" << endl;
	cout << "       B -- Brief Bank-Accounts Info Sorted Based on Aggregated Balances" << endl;
	cout << "       X -- Exit" << endl;

	cout << "Please enter your selection:";
}

int BankDetails::getAccountsNumber(){
	return AccNumber;
}

bool BankDetails::validateSSN(string ssn){
	if (ssn.length() != SSN_LENGTH){
		return false;
	}

	if (ssn[3] != '-' &&	ssn[6] != '-'){
		return false;
	}
	else{
		ssn = ssn.replace(3, 1, "");
		ssn = ssn.replace(5, 1, "");
		for (int i = 0; i < ssn.length(); ++i){
			if (!isdigit(ssn[i])){
				return false;
			}
		}
	}
	return true;
}

int BankDetails::open_Account(){
	string firstName;
	string lastName;
	string SSN;

	cout << "    Enter the first name of the account holder: ";
	cin >> firstName;
	cout << "    Enter the last name of the account holder: ";
	cin >> lastName;

	do{cout << "    Enter the SSN of the account holder: ";
		cin >> SSN;

		if (validateSSN(SSN)){
			break;
		}
		else{
			cout << "    | Error. Invalid SSN, needed to enter 9 digits. Pleasy try again." << endl << endl;
		}
	} while (true);
	return create_Account(firstName, lastName, SSN);
}

int BankDetails::create_Account(string firstName, string lastName, string ssn){
	if (AccNumber < MAX - 1){
		Username name(firstName, lastName);
		UserDeposit depositor(name, ssn);
		int unique = BankAcc++;
		ACCOUNTS[AccNumber++] = new AccountDetails(this, depositor, unique);
		cout << endl;
		cout << "    | A new Bank Account BNK" << unique << " was successfully created." << endl;
		cout << endl << endl;
		return unique;
	}
	return -1;
}

void BankDetails::close_Account(){
	string accountName;

	cout << "    Enter the sub-account number to close:";
	cin >> accountName;

	if (accountName.rfind("BNK", 0) == 0){
		accountName = accountName.replace(accountName.begin(), accountName.begin() + 3, "");

		{
			int num1 = stoi(accountName);

			int index = findAccountByNum(num1);

			if (index != -1){
				if (deleteBankAccount(index)){
					cout << "    | Account is closed." << endl;

					cout << endl << endl;

					return;
				}
				else{
					cout << "    | Error. Cannot close account." << endl;

					cout << endl << endl;

					return;
				}
			}
		}
	}
	cout << "    | Invalid account, please try again." << endl << endl << endl;
}

AccountDetails* BankDetails::mod_Account(){
	string accountName;
	AccountDetails* account = NULL;

	cout << "    Enter the sub-account number to modify:";
	cin >> accountName;

	if (accountName.rfind("BNK", 0) == 0){
		accountName = accountName.replace(accountName.begin(), accountName.begin() + 3, "");

		{
			int num1 = stoi(accountName);

			int index = findAccountByNum(num1);

			if (index != -1)
			{
				account = ACCOUNTS[index];
			}
		}
		if (account != NULL){
			cout << endl << endl;

			return account;
		}
	}
	cout << "    | Invalid account, please try again." << endl << endl << endl;
	return NULL;
}

void BankDetails::getNumBankAccount(){
	int num = getAccountsNumber();
	cout << "    | The number of Bank-Account is " << num << endl << endl << endl;
}

void BankDetails::getNumSavAccount(){
	int num = getAccountsNumber();
	int sum = 0;

	for (int i = 0; i < num; ++i){
		sum += ACCOUNTS[i]->getOpenedSACounter();
	}
	cout << "    | The number of Saving-Account is " << sum << endl << endl << endl;
}

void BankDetails::getNumChkAccount(){
	int num = getAccountsNumber();
	int sum = 0;

	for (int i = 0; i < num; ++i){
		sum += ACCOUNTS[i]->getOpenedCACounter();
	}
	cout << "    | The number of Checking-Account is " << sum << endl << endl << endl;
}

void BankDetails::showDetailedAccount(){
	cout << endl << endl;
	cout << "    | Bank Name: " << BankName << endl;
	cout << "    | Bank Address: " << BankAddress << endl;
	cout << "    | Bank Working Hours: " << BankWorkingHours << endl;

	double aggregatedBalance = 0;

	for (int i = 0; i < AccNumber; ++i){
		aggregatedBalance += ACCOUNTS[i]->getAggregatedBalance();
	};

	cout << "    | Aggregated Balance: " << aggregatedBalance << endl;
	cout << "    | Consists of " << fixed << setprecision(0) << AccNumber << " Banks-Accounts" << endl;
	cout << endl;

	for (int i = 0; i < AccNumber; ++i){
		ACCOUNTS[i]->ShowAccountDetails();
	};
}

void quickSort(vector<AccountDetails>& array, int left, int right){
	int ltemp = left;
	int rtemp = right;

	AccountDetails f = array[(left + right) / 2];

	while (ltemp < rtemp){
		while (array[ltemp].getAggregatedBalance() < f.getAggregatedBalance()){
			ltemp++;
		}

		while (array[rtemp].getAggregatedBalance() > f.getAggregatedBalance()){
			rtemp--;
		}

		if (ltemp < rtemp){
			AccountDetails temp = array[ltemp];
			array[ltemp] = array[rtemp];
			array[rtemp] = temp;
			ltemp++;
			rtemp--;
		}
	}

	if (ltemp == rtemp){
		ltemp++;
	}

	if (left < rtemp){
		quickSort(array, left, ltemp - 1);
	}

	if (ltemp < right){
		quickSort(array, rtemp + 1, right);
	}
}

void BankDetails::showBriefAccountInfo(){
	cout << endl << endl;
	cout << "    | Bank Name: " << BankName << endl;
	cout << "    | Bank Address: " << BankAddress << endl;
	cout << "    | Bank Working Hours: " << BankWorkingHours << endl;

	double aggregatedBalance = 0;

	for (int i = 0; i < AccNumber; ++i){
		aggregatedBalance += ACCOUNTS[i]->getAggregatedBalance();
	};

	cout << "    | Aggregated Balance: " << aggregatedBalance << endl;
	cout << "    | Consists of " << fixed << setprecision(0) << AccNumber << " Banks-Accounts" << endl;

	vector<AccountDetails> vec1;

	for (int i = 0; i < AccNumber; i++){
		vec1.push_back(*ACCOUNTS[i]);
	}

	quickSort(vec1, 0, vec1.size() - 1);

	for (int i = 0; i < AccNumber; i++){
		AccountDetails _temp = vec1[i];
		cout << "    | Aggregated Balance of the bank account : BNK" << _temp.getAccountNumber() << " with " << _temp.getNumberOfSubAccount() << " Sub-Accounts is " << fixed << setprecision(0) << _temp.getAggregatedBalance() << endl;
	}
	vec1.clear();
	cout << endl << endl;
}

int BankDetails::getSavAccountNum(){
	return SavingAcc++;
}

int BankDetails::getChkAccountNum(){
	return CheckingAcc++;
}

int BankDetails::findAccountByNum(int accountNumber){
	for (int i = 0; i < AccNumber; ++i){
		if (ACCOUNTS[i]->getAccountNumber() == accountNumber){
			return i;
		}
	}
	return -1;
}

int BankDetails::findAccountBySocial(string ssn){
	for (int i = 0; i < AccNumber; ++i){
		if (ACCOUNTS[i]->getUDeposit().getSSN() == ssn){
			return i;
		}
	}

	return -1;
}

AccountDetails* BankDetails::getAccount(int i){
	return ACCOUNTS[i];
}

bool BankDetails::deleteBankAccount(int index){
	if (index >= 0 &&	index < AccNumber){
		for (int i = index; i < AccNumber; ++i){
			ACCOUNTS[i] = ACCOUNTS[i + 1];
		}
		AccNumber--;
		return true;
	}
	else{
		return false;
	}
}