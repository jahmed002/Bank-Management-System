// Junaid Ahmed

#pragma once
#include <stdio.h>
#include <string>
#include "BaseAccount.hpp"

#define BONUS 100

using namespace std;

class SavAccount : public BaseAccount {
private:
public:
    SavAccount();
    SavAccount(int a_num, double balance);
    ~SavAccount(void);

    bool loop();
};
