//Junaid Ahmed

#include <iomanip>
#include <iostream>
#include "AccountDetails.hpp"
#include "BankDetails.hpp"
#include "SavAccount.hpp"

using namespace std;

AccountDetails::AccountDetails(void){
	SA_Counter = 0;
	SA_Capacity = 1;
	SAccounts = new SavAccount[SA_Capacity];
	CA_Counter = 0;
	CA_Capacity = 1;
	CAccounts = new ChkAccount[CA_Capacity];
}

AccountDetails::~AccountDetails(void){
	delete[] SAccounts;
	delete[] CAccounts;
}

AccountDetails::AccountDetails(BankDetails* bank, UserDeposit& depositor, int accountNumber){
	bankA = bank;
	depositA = depositor;
	Acc_Number = accountNumber;
	SA_Counter = 0;
	SA_Capacity = 1;
	SAccounts = new SavAccount[SA_Capacity];
	CA_Counter = 0;
	CA_Capacity = 1;
	CAccounts = new ChkAccount[CA_Capacity];
}

AccountDetails::AccountDetails(const AccountDetails& acc1){					
	copyFrom(acc1);
}

AccountDetails& AccountDetails::operator=(const AccountDetails& a){			
	if (this == &a)
	{
		return *this;
	}

	copyFrom(a);

	return *this;
}

void AccountDetails::copyFrom(const AccountDetails& a1){					
	bankA = a1.bankA;
	depositA = UserDeposit(a1.depositA);
	Acc_Number = a1.Acc_Number;
	SA_Capacity = a1.SA_Capacity;
	SA_Counter = a1.SA_Counter;
	SAccounts = new SavAccount[SA_Capacity];
	for (int i = 0; i < SA_Counter; ++i){
		SAccounts[i] = a1.SAccounts[i];
	}
	CA_Capacity = a1.CA_Capacity;
	CA_Counter = a1.CA_Counter;
	CAccounts = new ChkAccount[CA_Capacity];
	for (int i = 0; i < CA_Counter; ++i){
		CAccounts[i] = a1.CAccounts[i];
	}
}

bool AccountDetails::loop(){
	string input;													
	bool exit = false;												
	if (MenuNumber == 0){
		accountMenu();
		cin >> input;

		if (input == "x" || input == "X"){
			cout << endl;
			cout << "    | End of service for bank-account BNK" << Acc_Number << endl;
			cout << endl;
			cout << endl;
			exit = true;
		}
		else if (input == "s" || input == "S"){
			NewSavAccount();
		}
		else if (input == "c" || input == "C"){
			NewChkAccount();
		}
		else if (input == "b" || input == "B"){
			briefBankAccountDetails();
		}
		else if (input == "d" || input == "D"){
			DetailedBankAccount();
		}
		else if (input == "m" || input == "M"){
			ModifySubAccount();
		}
		else if (input == "e" || input == "E"){
			CloseSubAccount();
		}
		else{
			cout << "    | Invalid enter, please try again." << endl;
			cout << endl;
			cout << endl;
		}
	}
	else if (MenuNumber == 1){
		if (ModifyAccount->loop()){
			MenuNumber = 0;
			ModifyAccount = NULL;
		}
	}

	return exit;
}

void AccountDetails::accountMenu(){
	cout << "Eligible services for Bank-Account BNK" << Acc_Number << endl;
	cout << "       S -- Open Saving Sub-Account" << endl;
	cout << "       C -- Open Checking Sub-Account" << endl;
	cout << "       M -- Modify a Sub-Account" << endl;
	cout << "       E -- Close a Sub-Account" << endl;
	cout << "       D -- Detailed Bank Account Info Sorted Based on Balances of Sub-Account" << endl;
	cout << "       B -- Brief Bank Account Info" << endl;
	cout << "       X -- Exit" << endl;
	cout << "Please enter your selection:";
}

void AccountDetails::NewSavAccount(){
	string input;
	double initialBalance = 0;

	do {cout << "    Enter the initial balance: ";
		cin >> input;
			char* end = nullptr;
			initialBalance = strtod(input.c_str(), &end);
			if (initialBalance > 0){
				break;
			}
		cout << "    | Invalid initial balance, please try again.." << endl << endl;
	} while (true);

	int numA = bankA->getSavAccountNum();
	OpenSavAccount(SavAccount(numA, initialBalance));
	cout << "    | A new Saving Sub-Account SAV" << numA << " was successfully created." << endl << endl;
}

void AccountDetails::OpenSavAccount(SavAccount SSAccount){				
	if (SA_Counter >= SA_Capacity - 1){
		SA_Capacity = SA_Capacity * 2;
		SavAccount* newSavSubAccount = new SavAccount[SA_Capacity];
		for (int i = 0; i < SA_Counter; ++i){
			newSavSubAccount[i] = SAccounts[i];
		}
		delete[] SAccounts;
		SAccounts = newSavSubAccount;
	}

	SAccounts[SA_Counter] = SSAccount;
	SA_Counter++;
}

bool AccountDetails::CloseSavAccount(int ID){
	for (int i = 0; i < getSACounter(); ++i){
		if (SAccounts[i].getAccountNumber() == ID){
			SAccounts[i].closed();
				return true;
		}
	}
	return false;
}

int AccountDetails::getSACounter(){
	return SA_Counter;
}

int AccountDetails::getOpenedSACounter(){
	int Counter = 0;							
	for (int i = 0; i < SA_Counter; ++i){
		if (!SAccounts[i].isClosed()){
			Counter += 1;
		}
	}
	return Counter;
}

SavAccount* AccountDetails::getSAccount(int ID){
	for (int i = 0; i < getSACounter(); ++i){
		if (SAccounts[i].getAccountNumber() == ID){
			return &SAccounts[i];
		}
	}
	return NULL;
}

void AccountDetails::NewChkAccount(){
	string input;											
	double initialBalance = 0;
	double capacity = 0;
	string initialState;									
	bool locked = false;

	do {cout << "    Enter the initial balance: ";
		cin >> input;
			char* end = nullptr;
			initialBalance = strtod(input.c_str(), &end);

			if (initialBalance > 0){
				break;
			}
		cout << "    | Invalid initial balance, please try again.." << endl << endl;
	} while (true);

	do {cout << "    Enter the desired maximum capacity: ";
		cin >> input;

			char* end = nullptr;
			capacity = strtod(input.c_str(), &end);

			if (capacity > 0){
				break;
			}

		cout << "    | Invalid desired maximum capacity, please try again.." << endl << endl;
	} while (true);

	cout << "    Define initial state: (L - Locked, Othersise - Unlocked) ";
	cin >> initialState;

	if (initialState == "l" ||	initialState == "L"){
		locked = true;
	}

	int numA = bankA->getChkAccountNum();
	OpenChkAccount(ChkAccount(numA, initialBalance, capacity, locked));
	cout << "    | A new Checking Sub-Account CHK" << numA << " was successfully created." << endl << endl;
}

void AccountDetails::OpenChkAccount(ChkAccount chkSubAccount){
	if (CA_Counter >= CA_Capacity - 1){
		CA_Capacity = CA_Capacity * 2;
		ChkAccount* newChkSubAccount = new ChkAccount[CA_Capacity];
		for (int i = 0; i < CA_Counter; ++i){
			newChkSubAccount[i] = CAccounts[i];
		}
		delete[] CAccounts;
		CAccounts = newChkSubAccount;
	}
	CAccounts[CA_Counter] = chkSubAccount;
	CA_Counter++;
}

bool AccountDetails::CloseChkAccount(int ID){
	for (int i = 0; i < getCACounter(); ++i){
		if (CAccounts[i].getAccountNumber() == ID){
			CAccounts[i].closed();
			return true;
		}
	}
	return false;
}

int AccountDetails::getCACounter(){
	return CA_Counter;
}

int AccountDetails::getOpenedCACounter(){
	int subAccountCount = 0;
	for (int i = 0; i < CA_Counter; ++i){
		if (!CAccounts[i].isClosed()){
			subAccountCount += 1;
		}
	}
	return subAccountCount;
}

ChkAccount* AccountDetails::getCAccount(int ID){
	for (int i = 0; i < getCACounter(); ++i){
		if (CAccounts[i].getAccountNumber() == ID){
			return &CAccounts[i];
		}
	}
	return NULL;
}

void AccountDetails::ShowAccountDetails(){
	UserDeposit depositor = getUDeposit();
	cout << "    | Bank Account Number: BNK" << Acc_Number << endl;
	cout << "    | Account Holder Full Name: " << depositor.getName().getFirstname() << " " << depositor.getName().getLastname() << endl;
	cout << "    | Account Holder SSN: " << depositor.getSSN() << endl;
	cout << "    | Aggregated Balance: " << fixed << setprecision(0) << getAggregatedBalance() << endl;
	cout << "    | Consists of " << getNumberOfSubAccount() << " Sub-Accounts" << endl;

	DetailedBankAccount();

	cout << endl;
}

void AccountDetails::briefBankAccountDetails(){

	int subAccountCount = 0;
	double subAccountAmount = 0;
	for (int i = 0; i < SA_Counter; ++i){
		if (!SAccounts[i].isClosed()){
			subAccountCount += 1;
			subAccountAmount += SAccounts[i].getBalance();
		}
	}
	for (int i = 0; i < CA_Counter; ++i){
		if (!CAccounts[i].isClosed()){
			subAccountCount += 1;
			subAccountAmount += CAccounts[i].getBalance();
		}
	}
	cout << "    | Aggregated Balance of the bank account : BNK" << Acc_Number << " with " << subAccountCount << " Sub-Accounts is " << fixed << setprecision(0) << subAccountAmount << endl;
	cout << endl;
	cout << endl;
}

void AccountDetails::DetailedBankAccount(){
	MergeSort(SAccounts, CAccounts, SA_Counter, CA_Counter);
}

void AccountDetails::ModifySubAccount(){
	string accountName;
	cout << "    Enter the sub-account number to modify:";
	cin >> accountName;
	int type = 0;
	if (accountName.rfind("SAV", 0) == 0){
		type = 1;
	}
	else if (accountName.rfind("CHK", 0) == 0){
		type = 2;
	}

	if (type > 0){
		accountName = accountName.replace(accountName.begin(), accountName.begin() + 3, "");

			int id = stoi(accountName);

			if (type == 1){
				ModifyAccount = getSAccount(id);
			}
			else{
				ModifyAccount = getCAccount(id);
			}

		if (ModifyAccount != NULL){
			MenuNumber = 1;
			cout << endl;
			cout << endl;
		}
		else{
			cout << "    | Invalid account, please try again." << endl;
			cout << endl;
			cout << endl;
		}
	}
	else{
		cout << "    | Invalid account, please try again." << endl;
		cout << endl;
		cout << endl;
	}
}

void AccountDetails::CloseSubAccount(){
	string accountName;
	cout << "    Enter the sub-account number to be closed:";
	cin >> accountName;
	int type = 0;
	if (accountName.rfind("SAV", 0) == 0){
		type = 1;
	}
	else if (accountName.rfind("CHK", 0) == 0){
		type = 2;
	}

	if (type > 0){
		accountName = accountName.replace(accountName.begin(), accountName.begin() + 3, "");

			int id = stoi(accountName);

			cout << id << endl;

			if (type == 1){
				if (CloseSavAccount(id)){
					cout << "    | Sub-account SAV" << id << " was successfully closed." << endl;
					cout << endl;
					cout << endl;

					return;
				}
			}
			else{
				if (CloseChkAccount(id)){
					cout << "    | Sub-account CHK" << id << " was successfully closed." << endl;
					cout << endl;
					cout << endl;

					return;
				}
			}
	}
	cout << "    | Invalid account, please try again." << endl;
	cout << endl;
	cout << endl;
}

UserDeposit& AccountDetails::getUDeposit(){
	return depositA;
}

int AccountDetails::getAccountNumber(){
	return Acc_Number;
}

double AccountDetails::getAggregatedBalance(){
	double subAccountAmount = 0;
	for (int i = 0; i < SA_Counter; ++i){
		if (!SAccounts[i].isClosed()){
			subAccountAmount += SAccounts[i].getBalance();
		}
	}
	for (int i = 0; i < CA_Counter; ++i){
		if (!CAccounts[i].isClosed()){
			subAccountAmount += CAccounts[i].getBalance();
		}
	}
	return subAccountAmount;
}

int AccountDetails::getNumberOfSubAccount(){
	int subAccountCount = 0;

	for (int i = 0; i < SA_Counter; ++i){
		if (!SAccounts[i].isClosed()){
			subAccountCount += 1;
		}
	}
	for (int i = 0; i < CA_Counter; ++i){
		if (!CAccounts[i].isClosed()){
			subAccountCount += 1;
		}
	}
	return subAccountCount;
}

void AccountDetails::QuickSort(BaseAccount* array, int left, int right){
	int ltemp = left;
	int rtemp = right;

	BaseAccount f = array[(left + right) / 2];

	while (ltemp < rtemp){
		while (array[ltemp].getBalance() > f.getBalance()){
			ltemp++;
		}
		while (array[rtemp].getBalance() < f.getBalance()){
			rtemp--;
		}
		if (ltemp < rtemp){
			BaseAccount temp = array[ltemp];
			array[ltemp] = array[rtemp];
			array[rtemp] = temp;
			ltemp++;
			rtemp--;
		}
	}
	if (ltemp == rtemp){
		ltemp++;
	}
	if (left < rtemp){
		QuickSort(array, left, ltemp - 1);
	}
	if (ltemp < right){
		QuickSort(array, rtemp + 1, right);
	}
}

void AccountDetails::MergeSort(BaseAccount* a, BaseAccount* b, int c, int d){
	BaseAccount* nba = new BaseAccount[c + d];

	for (int i = 0; i < c; ++i){
		nba[i] = a[i];
	}
	for (int i = 0; i < d; ++i){
		nba[c + i] = b[i];
	}
	QuickSort(nba, 0, c + d - 1);
	for (int i = 0; i < c + d; ++i){
		if (!nba[i].isClosed()){
			nba[i].printAccountInfo();
		}
	}
	delete[]nba;
}