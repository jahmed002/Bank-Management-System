// Junaid Ahmed

#pragma once

#include <stdio.h>
#include "Username.hpp"

class UserDeposit {
    string SSN;
    Username Name;

public:
    UserDeposit(void);
    UserDeposit(const UserDeposit& u_deposit);
    UserDeposit(Username& name, string ssn);
    ~UserDeposit(void);

    Username& getName();
    string getSSN();
};
