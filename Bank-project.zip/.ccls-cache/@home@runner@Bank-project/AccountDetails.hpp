//Junaid Ahmed
#pragma once
#include <stdio.h>
#include "UserDeposit.hpp"
#include "SavAccount.hpp"
#include "ChkAccount.hpp"

class BankDetails;
class AccountDetails{
private:
	BankDetails* bankA;							
	UserDeposit depositA;						
	int Acc_Number;								

	int MenuNumber;								
	BaseAccount* ModifyAccount = NULL;			

	int SA_Capacity;							
	int SA_Counter;								
	SavAccount* SAccounts;						

	int CA_Capacity;							
	int CA_Counter;								
	ChkAccount* CAccounts;						

	void QuickSort(BaseAccount* arr, int left, int right);					
	void MergeSort(BaseAccount* a, BaseAccount* b, int c, int d);			
public:
	AccountDetails(void);
	AccountDetails(BankDetails* bank, UserDeposit& depositor, int accountNumber);
	AccountDetails(const AccountDetails& account);
	~AccountDetails(void);

	AccountDetails& operator=(const AccountDetails& other);

	bool loop();
	void accountMenu();

	void NewSavAccount();		
	void OpenSavAccount(SavAccount savSubAccount);			
	bool CloseSavAccount(int ID);							
	int getSACounter();										
	int getOpenedSACounter();							
	SavAccount* getSAccount(int ID);			

	void NewChkAccount();									
	void OpenChkAccount(ChkAccount chkSubAccount);	
	bool CloseChkAccount(int ID);							
	int getCACounter();										
	int getOpenedCACounter();								
	ChkAccount* getCAccount(int ID);				

	void ShowAccountDetails();							
	void briefBankAccountDetails();					
	void DetailedBankAccount();								
	void ModifySubAccount();								
	void CloseSubAccount();									

	UserDeposit& getUDeposit();							
	int getAccountNumber();									
	double getAggregatedBalance();					
	int getNumberOfSubAccount();			

private:
	void copyFrom(const AccountDetails& other);
};