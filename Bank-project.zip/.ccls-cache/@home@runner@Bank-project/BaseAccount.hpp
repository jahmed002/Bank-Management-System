// Junaid Ahmed

#pragma once
#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class BaseAccount {
private:
protected:
    int AccountNumber;
    double Balance;
    double Capacity;
    bool Locked;
    int Type;
    bool Closed = false;

public:
    BaseAccount();
    BaseAccount(int a_num, double balance);
    BaseAccount(int a_num);
    ~BaseAccount(void);

    virtual int getAccountNumber();
    virtual double getBalance();

    double getAmount();

    void deposit();
    void withdraw();

    virtual void ToDeposit(double amount);
    virtual bool ToWithdraw(double amount);
    virtual void printAccountInfo();

    void closed();
    bool isClosed();

    virtual bool loop();
};
