// Junaid Ahmed

#include "SavAccount.hpp"

SavAccount::SavAccount() {
}

SavAccount::SavAccount(int a_num, double balance) : BaseAccount(a_num, balance + BONUS) {
    Type = 1;
}

SavAccount::~SavAccount(void) {
}

bool SavAccount::loop() {
    string UserInput;
    bool exit = false;

    cout << endl;
    cout << endl;
    cout << "Eligible services for sub-account CHK" << AccountNumber << endl;
    cout << "        D -- Deposit" << endl;
    cout << "        W -- Withdraw" << endl;
    cout << "        X -- Exit" << endl;

    cout << "Please enter your selection:";
    cin >> UserInput;

    if (UserInput == "X" || UserInput == "x") {
        cout << "    | End of service for sub-account SAV" << AccountNumber << endl;
        cout << endl;
        cout << endl;
        exit = true;
    } else if (UserInput == "D" || UserInput == "d") {
        deposit();
    } else if (UserInput == "W" || UserInput == "w") {
        withdraw();
    }

    return exit;
}
