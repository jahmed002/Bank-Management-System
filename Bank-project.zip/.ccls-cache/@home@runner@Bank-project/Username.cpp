// Junaid Ahmed

#include "Username.hpp"

Username::Username(void) {
}

Username::~Username(void) {
}

Username::Username(const Username& name) {
    FirstName = name.FirstName;
    LastName = name.LastName;
}

Username::Username(string fName, string lName) {
    FirstName = fName;
    LastName = lName;
}

string Username::getFirstname() {
    return FirstName;
}

string Username::getLastname() {
    return LastName;
}
